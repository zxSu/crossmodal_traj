def print_variable(var, name):
    print('======>' + name)
    print(var)